
# #############################################
# Create Agent
# #############################################


agents_culture<-function(position, attributes){
	
	agent_def<-list()
	agent_def$position<-position
	agent_def$attributes<-attributes
	return(agent_def)
	
}